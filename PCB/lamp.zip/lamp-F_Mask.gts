G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.8*
G04 #@! TF.CreationDate,2026-04-18T23:53:31+05:30*
G04 #@! TF.ProjectId,lamp,6c616d70-2e6b-4696-9361-645f70636258,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.8) date 2026-04-18 23:53:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.905000X2.000000*%
%ADD11O,1.905000X2.000000*%
%ADD12RoundRect,0.102000X-0.679000X-0.679000X0.679000X-0.679000X0.679000X0.679000X-0.679000X0.679000X0*%
%ADD13C,1.562000*%
%ADD14R,1.700000X1.700000*%
%ADD15C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,Q1*
X111920000Y-98500000D03*
D11*
X114460000Y-98500000D03*
X117000000Y-98500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,U1*
X110760000Y-76260000D03*
D13*
X110760000Y-78800000D03*
X110760000Y-81340000D03*
X110760000Y-83880000D03*
X110760000Y-86420000D03*
X110760000Y-88960000D03*
X110760000Y-91500000D03*
X126000000Y-91500000D03*
X126000000Y-88960000D03*
X126000000Y-86420000D03*
X126000000Y-83880000D03*
X126000000Y-81340000D03*
X126000000Y-78800000D03*
X126000000Y-76260000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,led*
X122460000Y-97000000D03*
D15*
X125000000Y-97000000D03*
G04 #@! TD*
M02*
